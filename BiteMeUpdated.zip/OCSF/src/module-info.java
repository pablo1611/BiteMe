module OCSF {
    exports ocsf.client;
    exports ocsf.server;
}
