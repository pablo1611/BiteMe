package common;

public enum RequestType {
    USER_LOGIN,
    USER_LOGOUT,
    ORDER_DETAILS,
    CREATE_USER,
}

