package entities;

public class RevenueReport extends Report {
    private float totalRevenue;

    // Getters and Setters
    public float getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(float totalRevenue) {
        this.totalRevenue = totalRevenue;
    }
}

