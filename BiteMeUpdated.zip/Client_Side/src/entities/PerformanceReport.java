package entities;

public class PerformanceReport extends Report {
    private String performanceStatus;

    // Getters and Setters
    public String getPerformanceStatus() {
        return performanceStatus;
    }

    public void setPerformanceStatus(String performanceStatus) {
        this.performanceStatus = performanceStatus;
    }
}
