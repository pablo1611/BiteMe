package entities;

public class CEO {
    private boolean isCEO;

    // Getters and Setters
    public boolean isCEO() {
        return isCEO;
    }

    public void setCEO(boolean isCEO) {
        this.isCEO = isCEO;
    }
}
