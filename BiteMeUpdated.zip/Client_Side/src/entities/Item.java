package entities;

public class Item {

}
